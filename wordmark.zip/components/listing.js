const ListingComponent = ({ props }) => {
  let viewMode = "grid";
  let page = 1;
  let sortBy = "recentes";
  const pageSize = 4;
  const routeInfo = props.getRouteInfo?.() || {};
  const operation = routeInfo.operation || "comprar";
  const defaultMaxPrice = operation === "alugar" ? 10000 : 2500000;
  let lastUrlHash = "";
  const filters = {
    kinds: new Set(),
    city: "Todos",
    neighborhood: "Todos",
    maxPrice: defaultMaxPrice,
    bedrooms: "Qualquer",
    suites: "Qualquer",
    parking: "Qualquer",
    minArea: "Qualquer",
    features: new Set(),
  };


  const garageSpaces = (property = {}) => {
    const raw = [
      property.parking,
      property.garage,
      property.garages,
      property.garagem,
      property.vagas,
      property.garageSpaces,
      property.parkingSpaces,
    ].find((value) => value !== undefined && value !== null && value !== "");

    if (typeof raw === "number" && Number.isFinite(raw)) {
      return Math.max(0, raw);
    }

    const normalized = String(raw ?? "")
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "")
      .trim()
      .toLowerCase();

    if (/^(sim|yes|true)$/.test(normalized)) return 1;
    if (/^(nao|no|false)$/.test(normalized)) return 0;

    const match = normalized.match(/\d+/);
    return match ? Number(match[0]) : 0;
  };

  const matchesGarageFilter = (property, value) => {
    const spaces = garageSpaces(property);

    if (value === "Qualquer") return true;
    if (value === "com") return spaces > 0;
    if (value === "sem") return spaces === 0;

    const minimum = Number(String(value).replace("+", ""));
    return !Number.isFinite(minimum) || spaces >= minimum;
  };

  const filterProperties = () => {
    const filtered = properties.filter((property) => {
      const minBedrooms =
        filters.bedrooms === "Qualquer"
          ? 0
          : Number(filters.bedrooms.replace("+", ""));
      const minSuites =
        filters.suites === "Qualquer"
          ? 0
          : Number(filters.suites.replace("+", ""));
      const minArea =
        filters.minArea === "Qualquer" ? 0 : Number(filters.minArea);
      const features = propertyFeatures(property);
      return (
        (filters.kinds.size === 0 || filters.kinds.has(property.kind)) &&
        (filters.city === "Todos" || property.cityName === filters.city) &&
        (filters.neighborhood === "Todos" ||
          property.neighborhood === filters.neighborhood) &&
        property.priceNumber <= Number(filters.maxPrice) &&
        (minBedrooms === 0 || property.bedrooms >= minBedrooms) &&
        (minSuites === 0 || property.suites >= minSuites) &&
        matchesGarageFilter(property, filters.parking) &&
        (minArea === 0 || property.area >= minArea) &&
        (filters.features.size === 0 ||
          [...filters.features].every((feature) =>
            features.has(feature.toLowerCase()),
          )) &&
        (operation === "alugar"
          ? property.purpose === "locacao" || /alug|locacao/i.test(String(property.type || ""))
          : property.purpose === "venda" || /vend/i.test(String(property.type || "")))
      );
    });
    return [...filtered].sort((a, b) => {
      if (sortBy === "menor-preco") return a.priceNumber - b.priceNumber;
      if (sortBy === "maior-preco") return b.priceNumber - a.priceNumber;
      if (sortBy === "maior-area") return b.area - a.area;
      return properties.indexOf(a) - properties.indexOf(b);
    });
  };

  const resetFilters = () => {
    filters.kinds.clear();
    filters.features.clear();
    filters.city = "Todos";
    filters.neighborhood = "Todos";
    filters.maxPrice = defaultMaxPrice;
    filters.bedrooms = "Qualquer";
    filters.suites = "Qualquer";
    filters.parking = "Qualquer";
    filters.minArea = "Qualquer";
    sortBy = "recentes";
    page = 1;
  };

  const syncUrl = () => {
    const params = new URLSearchParams();
    if (filters.kinds.size) params.set("tipo", [...filters.kinds].join(","));
    if (filters.city !== "Todos") params.set("cidade", filters.city);
    if (filters.neighborhood !== "Todos")
      params.set("bairro", filters.neighborhood);
    if (Number(filters.maxPrice) < defaultMaxPrice)
      params.set("preco", filters.maxPrice);
    if (filters.bedrooms !== "Qualquer")
      params.set("quartos", filters.bedrooms);
    if (filters.suites !== "Qualquer") params.set("suites", filters.suites);
    if (filters.parking !== "Qualquer") params.set("garagem", filters.parking);
    if (filters.minArea !== "Qualquer") params.set("area", filters.minArea);
    if (filters.features.size)
      params.set("caracteristicas", [...filters.features].join(","));
    if (operation !== "comprar") params.set("operation", operation);
    if (sortBy !== "recentes") params.set("ordem", sortBy);
    if (page > 1) params.set("pagina", String(page));
    const query = params.toString();
    const newHash = `#comprar${query ? `?${query}` : ""}`;
    window.history.replaceState(
      { route: "comprar" },
      "",
      newHash,
    );
    lastUrlHash = newHash;
  };

  return {
    next(message = {}) {
      const currentHash = window.location.hash;
      if (currentHash !== lastUrlHash) {
        lastUrlHash = currentHash;
        
        // Parse parameters from window.location.hash
        const [, queryPart = ""] = currentHash.split("?");
        const params = new URLSearchParams(queryPart);
        
        if (params.has("tipo") || params.has("type")) {
          const t = params.get("tipo") || params.get("type");
          filters.kinds = new Set(t.split(",").map(item => item.trim()).filter(Boolean));
        } else {
          filters.kinds.clear();
        }
        
        if (params.has("cidade") || params.has("city")) {
          filters.city = params.get("cidade") || params.get("city");
        } else {
          filters.city = "Todos";
        }

        if (params.has("bairro") || params.has("neighborhood")) {
          const nb = params.get("bairro") || params.get("neighborhood");
          const firstNb = nb.split(",")[0];
          filters.neighborhood = firstNb === "(Selecionar tudo)" ? "Todos" : firstNb;
        } else {
          filters.neighborhood = "Todos";
        }
        
        if (params.has("preco")) {
          filters.maxPrice = Number(params.get("preco"));
        } else {
          filters.maxPrice = defaultMaxPrice;
        }
        
        if (params.has("quartos")) {
          filters.bedrooms = params.get("quartos");
        } else {
          filters.bedrooms = "Qualquer";
        }
        
        const garageParam =
          params.get("garagem") ||
          params.get("vagas") ||
          params.get("garage") ||
          params.get("parking");

        filters.parking = garageParam || "Qualquer";
        
        if (params.has("area")) {
          filters.minArea = params.get("area");
        } else {
          filters.minArea = "Qualquer";
        }
      }

      if (message.type === "toggleFavorite")
        props.toggleFavorite(message.propertyId);
      if (message.type === "setView") viewMode = message.value || viewMode;
      if (message.type === "sort") {
        sortBy = message.value || sortBy;
        page = 1;
      }
      if (message.type === "filter") {
        if (message.name === "kind") {
          if (message.checked) filters.kinds.add(message.value);
          else filters.kinds.delete(message.value);
        } else if (message.name === "feature") {
          if (message.checked) filters.features.add(message.value);
          else filters.features.delete(message.value);
        } else if (message.name in filters) {
          filters[message.name] = message.value;
          if (message.name === "city") filters.neighborhood = "Todos";
        }
        page = 1;
      }
      if (message.type === "clearFilters") resetFilters();
      if (message.type === "setPage") page = Number(message.value) || 1;

      const filtered = filterProperties();
      const totalPages = Math.max(1, Math.ceil(filtered.length / pageSize));
      page = Math.min(Math.max(page, 1), totalPages);
      syncUrl();
      const visibleProperties = filtered.slice(
        (page - 1) * pageSize,
        page * pageSize,
      );
      const neighborhoods = [
        "Todos",
        ...new Set(
          properties
            .filter(
              (property) =>
                filters.city === "Todos" || property.cityName === filters.city,
            )
            .map((property) => property.neighborhood),
        ),
      ];
      const renderPropertyCard = (property) =>
        PropertyCardComponent({
          props: {
            property,
            tools: {
              componentId: "listing",
              isFavorite: props.isFavorite,
            },
          },
        }).next().value;
      const renderListCard = (property) =>
        ListCardComponent({
          props: {
            property,
            tools: {
              componentId: "listing",
              isFavorite: props.isFavorite,
            },
          },
        }).next().value;
      const pager = Array.from({ length: totalPages }, (_, index) => index + 1)
        .map(
          (item) =>
            `<button class="${item === page ? "active" : ""}" type="button" data-cid="listing" data-message="setPage" data-value="${item}">${item}</button>`,
        )
        .join("");

      return {
        done: false,
        value: /*html*/ `
          <section id="comprar" class="section listing-section">
            <div class="container">
              <div class="section-title">
                <div><span class="eyebrow">Vitoria da Conquista / BA</span><h2>${operation === "alugar" ? "Comparaveis de locacao" : "Comparaveis de venda"}</h2><p>${filtered.length} referencias observadas. Precos pedidos, imagens ilustrativas e disponibilidade a confirmar na fonte.</p></div>
              </div>
              <div class="listing-layout">
                <aside class="filter-box" aria-label="Filtros">
                  <div class="filter-head"><strong>Filtros</strong><button type="button" data-cid="listing" data-message="clearFilters">Limpar filtros</button></div>
                  <div class="filter-stack">
                    <div class="mini-field"><label id="tipo-filter-title">Tipo</label><div class="check-list">${["Casa", "Apartamento", "Terreno", "Cobertura", "Sala comercial"].map((kind) => /*html*/ `<label>${kind}<input type="checkbox" data-cid="listing" data-message="filter" data-name="kind" value="${kind}" ${filters.kinds.has(kind) ? "checked" : ""}></label>`).join("")}</div></div>
                    <div class="mini-field"><label>Cidade</label><select data-cid="listing" data-message="filter" data-name="city">${["Todos", ...new Set(properties.map((property) => property.cityName))].map((city) => option(city, filters.city)).join("")}</select></div>
                    <div class="mini-field"><label>Bairro</label><select data-cid="listing" data-message="filter" data-name="neighborhood">${neighborhoods.map((item) => option(item, filters.neighborhood)).join("")}</select></div>
                    <div class="mini-field">
                      <label>
                        Preco maximo: R$
                        <span data-price-preview>${money(filters.maxPrice)}</span>
                      </label>
                      <input
                        type="range"
                        min="${operation === "alugar" ? 500 : 100000}"
                        max="${defaultMaxPrice}"
                        step="${operation === "alugar" ? 100 : 25000}"
                        value="${filters.maxPrice}"
                        data-cid="listing"
                        data-name="maxPrice"
                        oninput="this.previousElementSibling.querySelector('[data-price-preview]').textContent = Number(this.value).toLocaleString('pt-BR')"
                        onchange="this.dataset.message = 'filter'"
                      >
                    </div>
                    <div class="mini-field"><label>Quartos</label><select data-cid="listing" data-message="filter" data-name="bedrooms">${["Qualquer", "1+", "2+", "3+", "4+"].map((value) => option(value, filters.bedrooms)).join("")}</select></div>
                    <div class="mini-field"><label>Suites</label><select data-cid="listing" data-message="filter" data-name="suites">${["Qualquer", "1+", "2+"].map((value) => option(value, filters.suites)).join("")}</select></div>
                    <div class="mini-field"><label>Garagem</label><select data-cid="listing" data-message="filter" data-name="parking">${[
                      ["Qualquer", "Qualquer"],
                      ["com", "Com garagem"],
                      ["sem", "Sem garagem"],
                      ["1+", "1 ou mais vaga"],
                      ["2+", "2 ou mais vagas"],
                      ["3+", "3 ou mais vagas"],
                      ["4+", "4 ou mais vagas"],
                    ].map(([value, label]) => option(value, filters.parking, label)).join("")}</select></div>
                    <div class="mini-field"><label>Area minima</label><select data-cid="listing" data-message="filter" data-name="minArea">${["Qualquer", "50", "100", "200", "400"].map((value) => option(value, filters.minArea, value === "Qualquer" ? value : `${value}m2`)).join("")}</select></div>
                    <div class="mini-field"><label>Caracteristicas</label><div class="check-list">${["vista mar", "praia", "condominio", "comercial"].map((feature) => /*html*/ `<label>${feature}<input type="checkbox" data-cid="listing" data-message="filter" data-name="feature" value="${feature}" ${filters.features.has(feature) ? "checked" : ""}></label>`).join("")}</div></div>
                  </div>
                </aside>
                <div>
                  <div class="list-toolbar">
                    <strong>Pagina ${page} de ${totalPages}</strong>
                    <label class="mini-field sort-field"><span>Ordenar por</span><select data-cid="listing" data-message="sort">${[
                      ["recentes", "Mais recentes"],
                      ["menor-preco", "Menor preco"],
                      ["maior-preco", "Maior preco"],
                      ["maior-area", "Maior area"],
                    ]
                      .map(([value, label]) => option(value, sortBy, label))
                      .join("")}</select></label>
                    <div class="view-toggle">
                      <button class="square-btn ${viewMode === "grid" ? "active" : ""}" type="button" data-cid="listing" data-message="setView" data-value="grid" aria-label="Modo grade" title="Modo grade"><span class="view-icon" aria-hidden="true">&#9638;</span></button>
                      <button class="square-btn ${viewMode === "list" ? "active" : ""}" type="button" data-cid="listing" data-message="setView" data-value="list" aria-label="Modo lista" title="Modo lista"><span class="view-icon" aria-hidden="true">&#9776;</span></button>
                    </div>
                  </div>
                  <div class="results-meta-strip">
                    <span>${filtered.length} resultados</span>
                  </div>
                  <div class="${viewMode === "grid" ? "property-grid listing-grid" : "list-stack"}">
                    ${visibleProperties.length ? visibleProperties.map((property) => (viewMode === "grid" ? renderPropertyCard(property) : renderListCard(property))).join("") : `<article class="list-card empty-list-card"><div class="list-info"><h3>Nenhuma referencia encontrada</h3><div class="location">Tente limpar filtros.</div></div></article>`}
                  </div>
                  <div class="pager"><button type="button" data-cid="listing" data-message="setPage" data-value="${page - 1}" ${page === 1 ? "disabled" : ""}>&#8249;</button>${pager}<button type="button" data-cid="listing" data-message="setPage" data-value="${page + 1}" ${page === totalPages ? "disabled" : ""}>&#8250;</button></div>
                </div>
              </div>
            </div>
          </section>
        `,
      };
    },
  };
};
