window.MezaninoRuntimeConfig = {
  apiBase: ""
};
