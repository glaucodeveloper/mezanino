"use strict";

/* BEGIN MEZANINO MAP NAVIGATION */
const MapNavigationComponent = ({ props }) => {
  let selectedPropertyId = null;
  let selectedType = "Todos";
  let selectedCity = "Todos";
  let selectedNeighborhood = "Todos";
  let mapInstance = null;
  let mountSequence = 0;

  const escapeText = (value) =>
    String(value ?? "")
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#39;");

  const allProperties = () => {
    if (typeof properties !== "undefined" && Array.isArray(properties))
      return properties;
    return Array.isArray(window.properties) ? window.properties : [];
  };

  const cleanLocationPart = (value) =>
    String(value ?? "")
      .replace(/\s+/g, " ")
      .replace(/^\s*[-–—|·,]+|[-–—|·,]+\s*$/g, "")
      .trim();

  const normalizedCity = (property) => {
    const explicit = cleanLocationPart(
      property.cityName ||
      property.municipality ||
      property.address?.city ||
      property.address?.municipality,
    );
    if (explicit) return explicit;

    const raw = cleanLocationPart(property.city);
    if (!raw) return "Sem cidade";

    const parts = raw
      .split(/[·|,]/)
      .map(cleanLocationPart)
      .filter(Boolean)
      .filter((part) => !/^[A-Z]{2}$/i.test(part));

    return parts.at(-1) || raw;
  };

  const propertyTypeValues = (property) => [
    property.kind,
    property.propertyType,
    property.category,
    property.type,
  ]
    .map(cleanLocationPart)
    .filter(Boolean)
    .filter((value, index, values) => values.indexOf(value) === index);

  const primaryPropertyType = (property) =>
    propertyTypeValues(property)[0] || "Imóvel";

  const locationQueries = (property) => {
    const address = property.address && typeof property.address === "object"
      ? property.address
      : {};
    const city = normalizedCity(property);
    const state = cleanLocationPart(
      property.state || property.uf || address.state || address.uf || "Bahia",
    );
    const neighborhood = cleanLocationPart(
      property.neighborhood || property.district || address.neighborhood || address.district,
    );
    const street = cleanLocationPart(
      property.street || property.streetName || address.street || address.road,
    );
    const number = cleanLocationPart(
      property.number || property.streetNumber || address.number || address.houseNumber,
    );
    const postalCode = cleanLocationPart(
      property.postalCode || property.zipCode || property.cep || address.postalCode || address.cep,
    );
    const descriptive = cleanLocationPart(
      property.fullAddress ||
      property.addressText ||
      property.locationText ||
      (typeof property.address === "string" ? property.address : "") ||
      (typeof property.location === "string" ? property.location : ""),
    );

    const join = (...parts) =>
      parts.map(cleanLocationPart).filter(Boolean).join(", ");

    return [
      join(descriptive, city, state, postalCode, "Brasil"),
      join(street, number, neighborhood, city, state, postalCode, "Brasil"),
      join(neighborhood, city, state, "Brasil"),
      join(city, state, "Brasil"),
    ]
      .filter((query) => query && query !== "Brasil")
      .filter((query, index, values) => values.indexOf(query) === index);
  };

  const locationQuery = (property) =>
    locationQueries(property)[0] || "Vitória da Conquista, Bahia, Brasil";

  const isBrazilPoint = (lat, lng) =>
    Number.isFinite(lat) &&
    Number.isFinite(lng) &&
    lat >= -34 && lat <= 6 &&
    lng >= -74 && lng <= -32;

  const embeddedCoordinates = (property) => {
    const candidates = [
      [property.latitude, property.longitude],
      [property.lat, property.lng],
      [property.location?.latitude, property.location?.longitude],
      [property.location?.lat, property.location?.lng],
      [property.coordinates?.lat, property.coordinates?.lng],
      [property.coordinates?.latitude, property.coordinates?.longitude],
      Array.isArray(property.coordinates)
        ? [property.coordinates[0], property.coordinates[1]]
        : [null, null],
    ];

    for (const [rawLat, rawLng] of candidates) {
      if (rawLat === null || rawLat === undefined || rawLat === "") continue;
      if (rawLng === null || rawLng === undefined || rawLng === "") continue;
      const lat = Number(rawLat);
      const lng = Number(rawLng);
      if (isBrazilPoint(lat, lng)) return [lat, lng];
    }

    return null;
  };

  const geocodeMemory = new Map();
  let lastGeocodeRequestAt = 0;

  const cacheKeyFor = (query) =>
    `mezanino:geocode:v2:${query.toLocaleLowerCase("pt-BR")}`;

  const readGeocodeCache = (query) => {
    if (geocodeMemory.has(query)) return geocodeMemory.get(query);

    try {
      const raw = localStorage.getItem(cacheKeyFor(query));
      if (!raw) return undefined;
      const parsed = JSON.parse(raw);
      const point = Array.isArray(parsed?.point) ? parsed.point.map(Number) : null;
      const normalized = point && isBrazilPoint(point[0], point[1]) ? point : null;
      geocodeMemory.set(query, normalized);
      return normalized;
    } catch {
      return undefined;
    }
  };

  const writeGeocodeCache = (query, point) => {
    geocodeMemory.set(query, point);
    try {
      localStorage.setItem(
        cacheKeyFor(query),
        JSON.stringify({ point, savedAt: new Date().toISOString() }),
      );
    } catch {}
  };

  const wait = (milliseconds) =>
    new Promise((resolve) => setTimeout(resolve, milliseconds));

  const searchCoordinates = async (query) => {
    const cached = readGeocodeCache(query);
    if (cached !== undefined) return cached;

    const elapsed = Date.now() - lastGeocodeRequestAt;
    if (elapsed < 1100) await wait(1100 - elapsed);
    lastGeocodeRequestAt = Date.now();

    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 12000);

    try {
      const url = new URL("https://nominatim.openstreetmap.org/search");
      url.searchParams.set("format", "jsonv2");
      url.searchParams.set("limit", "1");
      url.searchParams.set("countrycodes", "br");
      url.searchParams.set("addressdetails", "1");
      url.searchParams.set("accept-language", "pt-BR");
      url.searchParams.set("q", query);

      const response = await fetch(url.toString(), {
        headers: { Accept: "application/json" },
        signal: controller.signal,
      });
      if (!response.ok) throw new Error(`Geocodificação HTTP ${response.status}`);

      const results = await response.json();
      const lat = Number(results?.[0]?.lat);
      const lng = Number(results?.[0]?.lon);
      const point = isBrazilPoint(lat, lng) ? [lat, lng] : null;
      writeGeocodeCache(query, point);
      return point;
    } catch (error) {
      if (error?.name !== "AbortError")
        console.warn("Falha ao buscar localização:", query, error);
      return null;
    } finally {
      clearTimeout(timeout);
    }
  };

  const coordinatesOf = async (property) => {
    const embedded = embeddedCoordinates(property);
    if (embedded) return embedded;

    for (const query of locationQueries(property)) {
      const point = await searchCoordinates(query);
      if (point) return point;
    }

    return null;
  };

  const ensureLeaflet = () =>
    new Promise((resolve, reject) => {
      if (window.L) {
        resolve(window.L);
        return;
      }

      if (!document.querySelector('link[data-mezanino-leaflet="true"]')) {
        const link = document.createElement("link");
        link.rel = "stylesheet";
        link.href = "https://unpkg.com/leaflet@1.9.4/dist/leaflet.css";
        link.dataset.mezaninoLeaflet = "true";
        document.head.appendChild(link);
      }

      let script = document.querySelector('script[data-mezanino-leaflet="true"]');
      if (!script) {
        script = document.createElement("script");
        script.src = "https://unpkg.com/leaflet@1.9.4/dist/leaflet.js";
        script.dataset.mezaninoLeaflet = "true";
        script.async = true;
        document.head.appendChild(script);
      }

      script.addEventListener("load", () => resolve(window.L), { once: true });
      script.addEventListener("error", reject, { once: true });
    });

  const mountMap = async (items, activeId) => {
    const sequence = ++mountSequence;

    if (mapInstance) {
      try {
        mapInstance.remove();
      } catch {}
      mapInstance = null;
    }

    const node = document.getElementById("mezanino-property-map");
    const statusNode = document.getElementById("mezanino-map-status");
    if (!node) return;

    const setStatus = (text) => {
      if (statusNode) statusNode.textContent = text;
    };

    try {
      const L = await ensureLeaflet();
      if (sequence !== mountSequence || !node.isConnected) return;

      mapInstance = L.map(node, {
        zoomControl: true,
        scrollWheelZoom: false,
        attributionControl: true,
      }).setView([-14.8619, -40.8446], 7);

      L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
        maxZoom: 19,
        attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>',
      }).addTo(mapInstance);

      if (!items.length) {
        setStatus("Nenhum imóvel corresponde aos filtros");
        requestAnimationFrame(() => mapInstance?.invalidateSize());
        return;
      }

      const bounds = [];
      const occupied = new Map();
      let activePoint = null;
      let locatedCount = 0;

      const spreadDuplicatePoint = (point) => {
        const key = `${point[0].toFixed(5)},${point[1].toFixed(5)}`;
        const duplicateIndex = occupied.get(key) || 0;
        occupied.set(key, duplicateIndex + 1);
        if (!duplicateIndex) return point;

        const angle = duplicateIndex * 2.399963229728653;
        const radius = 0.00055 * Math.ceil(duplicateIndex / 5);
        return [
          point[0] + Math.sin(angle) * radius,
          point[1] + Math.cos(angle) * radius,
        ];
      };

      const addMarker = (property, point) => {
        const active = property.id === activeId;
        const icon = L.divIcon({
          className: `mezanino-map-pin${active ? " is-active" : ""}`,
          html: `
            <span class="mezanino-map-pin-shape" aria-hidden="true">
              <svg viewBox="0 0 48 62" role="img">
                <path d="M24 1C11.3 1 1 11.3 1 24c0 17.4 23 37 23 37s23-19.6 23-37C47 11.3 36.7 1 24 1Z"></path>
                <circle cx="24" cy="24" r="9"></circle>
              </svg>
            </span>
          `,
          iconSize: [42, 54],
          iconAnchor: [21, 52],
        });

        const marker = L.marker(point, {
          icon,
          title: property.title || "Imóvel",
        })
          .addTo(mapInstance)
          .bindTooltip(escapeText(property.title || "Imóvel"), {
            direction: "top",
            offset: [0, -48],
          });

        marker.on("click", () => {
          selectedPropertyId = property.id;
          props.requestRender?.();
        });

        bounds.push(point);
        if (active) activePoint = point;
      };

      for (let index = 0; index < items.length; index += 1) {
        if (sequence !== mountSequence || !node.isConnected) return;

        const property = items[index];
        setStatus(`Buscando localizações · ${index + 1}/${items.length}`);
        const rawPoint = await coordinatesOf(property);
        if (!rawPoint) continue;

        const point = spreadDuplicatePoint(rawPoint);
        addMarker(property, point);
        locatedCount += 1;

        if (locatedCount === 1) mapInstance.setView(point, 13, { animate: false });
        if (bounds.length > 1)
          mapInstance.fitBounds(bounds, { padding: [48, 48], maxZoom: 14 });
      }

      if (sequence !== mountSequence || !node.isConnected) return;

      if (activePoint) mapInstance.panTo(activePoint, { animate: false });
      setStatus(
        locatedCount
          ? `${locatedCount} de ${items.length} imóveis localizados por busca`
          : "Nenhuma localização encontrada nas descrições cadastradas",
      );

      requestAnimationFrame(() => mapInstance?.invalidateSize());
    } catch (error) {
      node.innerHTML = `
        <div class="map-load-error">
          Não foi possível carregar o mapa agora.<br>
          <small>${escapeText(error?.message || "Falha de rede")}</small>
        </div>
      `;
      setStatus("Falha ao carregar o mapa");
    }
  };

  return {
    next(message = {}) {
      if (message.type === "mapFilter") {
        if (message.name === "type") selectedType = message.value || "Todos";
        if (message.name === "city") {
          selectedCity = message.value || "Todos";
          selectedNeighborhood = "Todos";
        }
        if (message.name === "neighborhood")
          selectedNeighborhood = message.value || "Todos";
      }

      if (message.type === "mapReset") {
        selectedType = "Todos";
        selectedCity = "Todos";
        selectedNeighborhood = "Todos";
      }

      if (message.type === "mapSelect") selectedPropertyId = message.propertyId;

      if (message.type === "mapOpenProperty" && message.propertyId) {
        props.goToRoute?.("imovel", { propertyId: message.propertyId });
      }

      const source = allProperties();
      const cities = ["Todos", ...new Set(source.map(normalizedCity).filter(Boolean))];
      const neighborhoods = [
        "Todos",
        ...new Set(
          source
            .filter((property) =>
              selectedCity === "Todos" || normalizedCity(property) === selectedCity,
            )
            .map((property) => property.neighborhood)
            .filter(Boolean),
        ),
      ];
      const types = [
        "Todos",
        ...new Set(source.flatMap(propertyTypeValues)),
      ];

      const filtered = source.filter((property) => {
        const propertyTypes = propertyTypeValues(property);
        return (
          (selectedType === "Todos" || propertyTypes.includes(selectedType)) &&
          (selectedCity === "Todos" || normalizedCity(property) === selectedCity) &&
          (selectedNeighborhood === "Todos" || property.neighborhood === selectedNeighborhood)
        );
      });

      if (!filtered.some((property) => property.id === selectedPropertyId)) {
        selectedPropertyId = filtered[0]?.id || null;
      }

      const selected =
        filtered.find((property) => property.id === selectedPropertyId) || null;
      setTimeout(
        () => mountMap(filtered, selectedPropertyId),
        0,
      );

      const renderOption = (value, current, label = value) =>
        `<option value="${escapeText(value)}" ${value === current ? "selected" : ""}>${escapeText(label)}</option>`;

      const selectedMeta = Array.isArray(selected?.meta)
        ? selected.meta
        : [
            selected?.bedrooms ? `${selected.bedrooms} quartos` : "",
            selected?.parking ? `${selected.parking} vagas` : "",
            selected?.area ? `${selected.area} m²` : "",
          ].filter(Boolean);

      const googleMapsUrl = selected
        ? `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(locationQuery(selected))}`
        : "https://www.google.com/maps";

      return {
        done: false,
        value: /*html*/ `
          <section id="mapa-imoveis" class="section map-navigation-section">
            <style>
              .map-navigation-section {
                --map-blue: #082b59;
                --map-blue-2: #0c467f;
                --map-gold: #c8923e;
                --map-ink: #16273f;
                --map-border: rgba(22,39,63,.12);
                background: #f7f6f2;
              }
              .map-navigation-section .map-section-title {
                display: flex;
                justify-content: space-between;
                align-items: end;
                gap: 22px;
                margin-bottom: 24px;
              }
              .map-navigation-section .map-section-title h2 {
                margin: 8px 0 0;
                color: var(--map-ink);
                font-size: clamp(2rem, 4vw, 4.2rem);
                line-height: .95;
                letter-spacing: -.05em;
              }
              .map-navigation-section .map-section-title p {
                max-width: 540px;
                margin: 0;
                color: #687486;
                line-height: 1.65;
              }
              .map-navigation-section .property-map-layout {
                display: grid;
                grid-template-columns: 260px minmax(420px, 1fr) 330px;
                min-height: 610px;
                border: 1px solid var(--map-border);
                border-radius: 24px;
                overflow: hidden;
                background: #fff;
                box-shadow: 0 24px 70px rgba(18,39,66,.12);
              }
              .map-navigation-section .map-filter-panel,
              .map-navigation-section .map-detail-panel {
                padding: 26px;
                background: #fff;
              }
              .map-navigation-section .map-filter-panel {
                border-right: 1px solid var(--map-border);
              }
              .map-navigation-section .map-detail-panel {
                border-left: 1px solid var(--map-border);
              }
              .map-navigation-section .map-panel-heading {
                display: flex;
                justify-content: space-between;
                align-items: center;
                gap: 12px;
                margin-bottom: 22px;
              }
              .map-navigation-section .map-panel-heading strong {
                color: var(--map-ink);
                font-size: 1.05rem;
              }
              .map-navigation-section .map-reset-button {
                border: 0;
                padding: 0;
                background: transparent;
                color: var(--map-gold);
                cursor: pointer;
                font: inherit;
                font-size: .78rem;
                font-weight: 750;
              }
              .map-navigation-section .map-filter-stack {
                display: grid;
                gap: 18px;
              }
              .map-navigation-section .map-filter-field {
                display: grid;
                gap: 8px;
              }
              .map-navigation-section .map-filter-field label {
                color: #667386;
                font-size: .68rem;
                font-weight: 800;
                letter-spacing: .09em;
                text-transform: uppercase;
              }
              .map-navigation-section .map-filter-field select {
                width: 100%;
                min-height: 46px;
                padding: 0 12px;
                border: 1px solid rgba(22,39,63,.16);
                border-radius: 7px;
                outline: 0;
                background: #fff;
                color: var(--map-ink);
                font: inherit;
              }
              .map-navigation-section .map-filter-field select:focus {
                border-color: var(--map-gold);
                box-shadow: 0 0 0 3px rgba(200,146,62,.12);
              }
              .map-navigation-section .map-result-count {
                margin-top: 24px;
                padding: 15px;
                border-radius: 10px;
                background: #f2f5f8;
                color: #667386;
                font-size: .82rem;
                line-height: 1.45;
              }
              .map-navigation-section .map-result-count strong {
                display: block;
                color: var(--map-blue);
                font-size: 1.45rem;
              }
              .map-navigation-section .map-canvas-shell {
                position: relative;
                min-width: 0;
                background: #dde6ec;
              }
              .map-navigation-section #mezanino-property-map {
                width: 100%;
                height: 100%;
                min-height: 610px;
                background: #dfe7eb;
              }
              .map-navigation-section #mezanino-property-map .leaflet-tile-pane {
                filter: grayscale(.24) sepia(.22) hue-rotate(164deg) saturate(.72) brightness(1.03) contrast(.92);
              }
              .map-navigation-section #mezanino-property-map::after {
                content: "";
                position: absolute;
                inset: 0;
                z-index: 400;
                pointer-events: none;
                background: linear-gradient(135deg, rgba(8,43,89,.05), rgba(200,146,62,.035));
                mix-blend-mode: multiply;
              }
              .map-navigation-section .map-floating-label {
                position: absolute;
                top: 18px;
                left: 50%;
                z-index: 600;
                transform: translateX(-50%);
                padding: 10px 16px;
                border: 1px solid rgba(255,255,255,.72);
                border-radius: 999px;
                background: rgba(255,255,255,.91);
                box-shadow: 0 10px 30px rgba(16,42,70,.15);
                color: var(--map-ink);
                font-size: .76rem;
                font-weight: 750;
                backdrop-filter: blur(10px);
              }
              .map-navigation-section .mezanino-map-pin {
                border: 0;
                background: transparent;
              }
              .map-navigation-section .mezanino-map-pin-shape {
                display: block;
                width: 42px;
                height: 54px;
                filter: drop-shadow(0 8px 9px rgba(8,43,89,.28));
                transform-origin: 50% 100%;
                transition: transform .18s ease;
              }
              .map-navigation-section .mezanino-map-pin:hover .mezanino-map-pin-shape,
              .map-navigation-section .mezanino-map-pin.is-active .mezanino-map-pin-shape {
                transform: translateY(-4px) scale(1.12);
              }
              .map-navigation-section .mezanino-map-pin svg {
                width: 100%;
                height: 100%;
                overflow: visible;
              }
              .map-navigation-section .mezanino-map-pin path {
                fill: var(--map-blue-2);
                stroke: #fff;
                stroke-width: 2;
              }
              .map-navigation-section .mezanino-map-pin circle {
                fill: var(--map-gold);
                stroke: #fff;
                stroke-width: 2;
              }
              .map-navigation-section .mezanino-map-pin.is-active path {
                fill: var(--map-gold);
              }
              .map-navigation-section .mezanino-map-pin.is-active circle {
                fill: var(--map-blue);
              }
              .map-navigation-section .leaflet-control-zoom a {
                color: var(--map-blue);
              }
              .map-navigation-section .map-detail-panel {
                display: flex;
                flex-direction: column;
                min-width: 0;
              }
              .map-navigation-section .map-detail-image {
                width: 100%;
                aspect-ratio: 4 / 3;
                object-fit: cover;
                border-radius: 14px;
                background: #edf0f3;
              }
              .map-navigation-section .map-detail-type {
                display: block;
                margin-top: 22px;
                color: #7a837f;
                font-size: .68rem;
                font-weight: 800;
                letter-spacing: .09em;
                text-transform: uppercase;
              }
              .map-navigation-section .map-detail-panel h3 {
                margin: 8px 0 10px;
                color: var(--map-ink);
                font-size: 1.7rem;
                line-height: 1.05;
                letter-spacing: -.035em;
              }
              .map-navigation-section .map-detail-location {
                margin: 0;
                color: #6c7887;
                font-size: .86rem;
                line-height: 1.5;
              }
              .map-navigation-section .map-detail-meta {
                display: flex;
                flex-wrap: wrap;
                gap: 8px;
                margin: 18px 0;
              }
              .map-navigation-section .map-detail-meta span {
                padding: 7px 9px;
                border-radius: 6px;
                background: #f2f4f6;
                color: #506074;
                font-size: .72rem;
              }
              .map-navigation-section .map-detail-price {
                margin-top: auto;
                padding-top: 20px;
                color: var(--map-blue);
                font-size: 1.45rem;
              }
              .map-navigation-section .map-detail-actions {
                display: grid;
                grid-template-columns: 1fr 1fr;
                gap: 10px;
                margin-top: 18px;
              }
              .map-navigation-section .map-detail-actions a,
              .map-navigation-section .map-detail-actions button {
                display: inline-flex;
                align-items: center;
                justify-content: center;
                min-height: 46px;
                padding: 0 13px;
                border: 1px solid rgba(22,39,63,.14);
                border-radius: 7px;
                background: #fff;
                color: var(--map-ink);
                text-decoration: none;
                cursor: pointer;
                font: inherit;
                font-size: .78rem;
                font-weight: 750;
              }
              .map-navigation-section .map-detail-actions button {
                border-color: var(--map-blue);
                background: var(--map-blue);
                color: #fff;
              }
              .map-navigation-section .map-empty-detail,
              .map-navigation-section .map-load-error {
                display: grid;
                place-items: center;
                min-height: 100%;
                padding: 28px;
                color: #647184;
                text-align: center;
                line-height: 1.6;
              }
              @media (max-width: 1120px) {
                .map-navigation-section .property-map-layout {
                  grid-template-columns: 230px minmax(0, 1fr);
                }
                .map-navigation-section .map-detail-panel {
                  grid-column: 1 / -1;
                  display: grid;
                  grid-template-columns: 250px minmax(0, 1fr);
                  gap: 24px;
                  border-top: 1px solid var(--map-border);
                  border-left: 0;
                }
                .map-navigation-section .map-detail-price {
                  margin-top: 18px;
                }
              }
              @media (max-width: 760px) {
                .map-navigation-section .map-section-title,
                .map-navigation-section .property-map-layout,
                .map-navigation-section .map-detail-panel {
                  display: grid;
                  grid-template-columns: 1fr;
                }
                .map-navigation-section .map-filter-panel {
                  border-right: 0;
                  border-bottom: 1px solid var(--map-border);
                }
                .map-navigation-section #mezanino-property-map {
                  min-height: 480px;
                }
                .map-navigation-section .map-detail-actions {
                  grid-template-columns: 1fr;
                }
              }
            </style>

            <div class="container">
              <div class="map-section-title">
                <div>
                  <span class="eyebrow">Localização dos imóveis</span>
                  <h2>Explore pelo mapa</h2>
                </div>
                <p>Filtre os imóveis, selecione um marcador e consulte os detalhes sem sair da página inicial.</p>
              </div>

              <div class="property-map-layout">
                <aside class="map-filter-panel" aria-label="Filtros do mapa">
                  <div class="map-panel-heading">
                    <strong>Filtros</strong>
                    <button class="map-reset-button" type="button" data-cid="map-navigation" data-message="mapReset">Limpar</button>
                  </div>

                  <div class="map-filter-stack">
                    <div class="map-filter-field">
                      <label>Tipo de imóvel</label>
                      <select data-cid="map-navigation" data-message="mapFilter" data-name="type">
                        ${types.map((value) => renderOption(value, selectedType)).join("")}
                      </select>
                    </div>

                    <div class="map-filter-field">
                      <label>Cidade</label>
                      <select data-cid="map-navigation" data-message="mapFilter" data-name="city">
                        ${cities.map((value) => renderOption(value, selectedCity)).join("")}
                      </select>
                    </div>

                    <div class="map-filter-field">
                      <label>Bairro</label>
                      <select data-cid="map-navigation" data-message="mapFilter" data-name="neighborhood">
                        ${neighborhoods.map((value) => renderOption(value, selectedNeighborhood)).join("")}
                      </select>
                    </div>

                  </div>

                  <div class="map-result-count">
                    <strong>${filtered.length}</strong>
                    ${filtered.length === 1 ? "imóvel localizado" : "imóveis localizados"}
                  </div>
                </aside>

                <div class="map-canvas-shell">
                  <div id="mezanino-map-status" class="map-floating-label">Buscando localizações cadastradas</div>
                  <div id="mezanino-property-map" aria-label="Mapa dos imóveis"></div>
                </div>

                <aside class="map-detail-panel" aria-live="polite">
                  ${selected ? /*html*/ `
                    <img class="map-detail-image" src="${escapeText(selected.image || selected.images?.[0] || "")}" alt="${escapeText(selected.title || "Imóvel selecionado")}" loading="lazy">
                    <div>
                      <span class="map-detail-type">${escapeText(primaryPropertyType(selected))}</span>
                      <h3>${escapeText(selected.title || "Imóvel selecionado")}</h3>
                      <p class="map-detail-location">${escapeText([selected.neighborhood, normalizedCity(selected)].filter(Boolean).join(" · "))}</p>
                      <div class="map-detail-meta">
                        ${selectedMeta.map((item) => `<span>${escapeText(item)}</span>`).join("")}
                      </div>
                      <strong class="map-detail-price">${escapeText(selected.price || "Valor sob consulta")}</strong>
                      <div class="map-detail-actions">
                        <a href="${googleMapsUrl}" target="_blank" rel="noreferrer">Abrir no mapa</a>
                        <button type="button" data-cid="map-navigation" data-message="mapOpenProperty" data-property-id="${escapeText(selected.id)}">Ver detalhes</button>
                      </div>
                    </div>
                  ` : /*html*/ `
                    <div class="map-empty-detail">Nenhum imóvel corresponde aos filtros selecionados.</div>
                  `}
                </aside>
              </div>
            </div>
          </section>
        `,
      };
    },
  };
};
/* END MEZANINO MAP NAVIGATION */

const bootApp = (rootSelector = "#app") => {
  const root =
    document.querySelector(rootSelector) ||
    document.body.appendChild(
      Object.assign(document.createElement("div"), { id: "app" }),
    );
  root.classList.add("app-shell");
  const nativeDashboardOnly = Boolean(window.SuaImobiliariaCmsConfig?.nativeDashboardOnly || window.Capacitor);
  const dashboardAuditMode = Boolean(window.SuaImobiliariaCmsConfig?.dashboardAuditMode);
  root.classList.toggle("native-dashboard-app", nativeDashboardOnly);

  const initialRoute = parseRoute();
  const routeState = {
    state: {
      route: nativeDashboardOnly ? "dashboard" : initialRoute.route,
      selectedPropertyId: initialRoute.propertyId || properties[0]?.id || null,
      selectedBrokerId: initialRoute.brokerId || null,
      dashboardTab: initialRoute.dashboardTab || "overview",
      selectedEntityId: initialRoute.entityId || null,
      operation: initialRoute.operation || "comprar",
    },
    current() {
      return this.state;
    },
    apply(message = {}) {
      if (message.type !== "route") return this.state;
      const requestedRoute = ROUTES.includes(message.route) ? message.route : "home";
      const nextRoute = nativeDashboardOnly && requestedRoute !== "login" ? "dashboard" : requestedRoute;
      this.state = {
        ...this.state,
        route:
          message.authenticated || nextRoute !== "dashboard"
            ? nextRoute
            : "login",
        selectedPropertyId:
          message.propertyId ||
          this.state.selectedPropertyId ||
          properties[0]?.id ||
          null,
        selectedBrokerId:
          message.brokerId !== undefined
            ? message.brokerId
            : this.state.selectedBrokerId,
        dashboardTab:
          message.dashboardTab || this.state.dashboardTab || "overview",
        selectedEntityId:
          message.entityId !== undefined
            ? message.entityId
            : this.state.selectedEntityId,
        operation: message.operation || this.state.operation || "comprar",
      };
      return this.state;
    },
    setRoute(route, options = {}) {
      return this.apply({
        type: "route",
        route,
        propertyId: options.propertyId,
        brokerId: options.brokerId,
        dashboardTab: options.dashboardTab,
        entityId: options.entityId,
        operation: options.operation,
        authenticated: options.authenticated,
      });
    },
  };

  const sessionState = {
    state: {
      favorites: new Set(
        JSON.parse(localStorage.getItem("suaimobiliaria:favorites") || "[]"),
      ),
      authenticated: nativeDashboardOnly && dashboardAuditMode,
    },
    current() {
      return this.state;
    },
    apply(message = {}) {
      if (message.type === "toggleFavorite") {
        const favorites = new Set(this.state.favorites);
        if (favorites.has(message.propertyId))
          favorites.delete(message.propertyId);
        else favorites.add(message.propertyId);
        localStorage.setItem(
          "suaimobiliaria:favorites",
          JSON.stringify([...favorites]),
        );
        this.state = { ...this.state, favorites };
        return this.state;
      }
      if (message.type === "login") {
        this.state = { ...this.state, authenticated: true };
        return this.state;
      }
      if (message.type === "logout") {
        this.state = { ...this.state, authenticated: false };
        return this.state;
      }
      return this.state;
    },
  };

  const featuredHoverState = {};

  const removeCpfFields = (value) => {
    if (Array.isArray(value)) return value.map(removeCpfFields);
    if (!value || typeof value !== "object") return value;

    return Object.fromEntries(
      Object.entries(value)
        .filter(([key]) => key.toLowerCase() !== "cpf")
        .map(([key, item]) => [key, removeCpfFields(item)]),
    );
  };

  dashboardContent = removeCpfFields(dashboardContent);

  const dashboardState = {
    state: dashboardContent,
    current() {
      return this.state;
    },
    addLead(lead) {
      this.state = {
        ...dashboardContent,
        leads: [lead, ...dashboardContent.leads],
        activities: [
          {
            icon: "L",
            title: "Novo lead recebido",
            detail: lead.interest,
            time: "Agora",
            color: "var(--gold)",
            properties: [],
            brokers: [],
            clients: [],
          },
          ...dashboardContent.activities,
        ],
      };
      dashboardContent = this.state;
      return this.state;
    },
  };

  const components = new Map();
  const add = (id, createComponent, props = {}) => {
    const component = createComponent({ id, props });
    if (!component || typeof component.next !== "function")
      throw new Error(`Component ${id} must expose next().`);
    components.set(id, component);
    return component;
  };
  const getRoute = () => routeState.current().route;
  const getSession = () => sessionState.current();
  const getSelectedBroker = () =>
    brokers.find(
      (broker) =>
        (broker.id || slugify(broker.name || broker.title || "")) ===
        routeState.current().selectedBrokerId,
    ) ||
    brokers[0] ||
    null;
  let leadAuthModal = {
    open: false,
    mode: "login", // "login" or "register"
    error: "",
    leadData: null,
  };

  const submitLeadAndPersist = async (lead) => {
    dashboardState.addLead(lead);
    try {
      await persistCmsSnapshot(properties, dashboardContent);
      console.log("Lead persistido no CMS com sucesso!");
    } catch (err) {
      console.error("Erro ao persistir lead no CMS:", err);
    }
    render();
  };

  const addLead = (lead) => {
    const session = getSession();
    if (session.leadUser) {
      lead.name = session.leadUser.name;
      lead.phone = session.leadUser.phone || lead.phone;
      lead.email = session.leadUser.email || lead.email;
      submitLeadAndPersist(lead);
    } else {
      leadAuthModal.open = true;
      leadAuthModal.leadData = lead;
      leadAuthModal.mode = "login";
      leadAuthModal.error = "";
      render();
    }
  };
  let requestRender = () => {};
  const persistCmsSnapshot = async (
    nextProperties = properties,
    nextDashboard = dashboardContent,
    nextBrokers = brokers,
  ) => {
    return saveCmsDataToGitHub(
      removeCpfFields({
        properties: nextProperties,
        brokers: nextBrokers,
        dashboard: nextDashboard,
      }),
    );
  };
  const saveDashboard = async (nextDashboard = dashboardContent) => {
    const normalizedDashboard = normalizeDashboardContent(nextDashboard);
    dashboardContent = normalizedDashboard;
    dashboardState.state = normalizedDashboard;
    const result = await persistCmsSnapshot(properties, normalizedDashboard);
    propsSync();
    return { message: result?.message || "Alterações do CRM salvas." };
  };
  const saveProperty = async (draft, originalId = null) => {
    const normalized = normalizeDashboardItem("properties", draft);
    const nextProperties = properties.slice();
    const index = originalId
      ? nextProperties.findIndex((item) => item.id === originalId)
      : -1;
    if (index >= 0) nextProperties.splice(index, 1, normalized);
    else nextProperties.unshift(normalized);
    const result = await persistCmsSnapshot(nextProperties, dashboardContent);
    properties = nextProperties;
    propsSync();
    return { property: normalized, message: result?.message || "Imóvel salvo e publicado." };
  };
  const deleteProperty = async (propertyId) => {
    const nextProperties = properties.filter((item) => item.id !== propertyId);
    if (nextProperties.length === properties.length)
      throw new Error("Produto nao encontrado.");
    const result = await persistCmsSnapshot(nextProperties, dashboardContent);
    properties = nextProperties;
    propsSync();
    return { message: result?.message || "Imóvel removido." };
  };
  const saveBroker = async (draft, originalId = null) => {
    const normalized = {
      id:
        draft.id ||
        slugify(draft.name || draft.title || "vendedor") ||
        `vendedor-${Date.now()}`,
      name: draft.name || draft.title || "Vendedor",
      phone: draft.phone || "",
      photo: draft.photo || draft.image || "",
      creci: draft.creci || "",
      city: draft.city || "",
      specialty: draft.specialty || draft.role || "",
      bio: draft.bio || draft.note || "",
      performance: draft.performance || "",
      status: draft.status || "Ativo",
    };
    const nextBrokers = brokers.slice();
    const index = originalId
      ? nextBrokers.findIndex(
          (item) =>
            (item.id || slugify(item.name || item.title || "")) === originalId,
        )
      : -1;
    if (index >= 0) nextBrokers.splice(index, 1, normalized);
    else nextBrokers.unshift(normalized);
    const result = await persistCmsSnapshot(properties, dashboardContent, nextBrokers);
    brokers = nextBrokers;
    propsSync();
    return { broker: normalized, message: result?.message || "Vendedor salvo." };
  };
  const deleteBroker = async (brokerId) => {
    const nextBrokers = brokers.filter(
      (item) =>
        (item.id || slugify(item.name || item.title || "")) !== brokerId,
    );
    if (nextBrokers.length === brokers.length)
      throw new Error("Vendedor nao encontrado.");
    const result = await persistCmsSnapshot(properties, dashboardContent, nextBrokers);
    brokers = nextBrokers;
    propsSync();
    return { message: result?.message || "Vendedor removido." };
  };
  const propsSync = () => requestRender();
  const propertyTools = {
    requestRender: () => requestRender(),
    getRouteInfo: () => routeState.current(),
    getFeaturedScrollState: () => featuredScrollState,
    isFavorite: (id) => getSession().favorites.has(id),
    toggleFavorite: (id) =>
      sessionState.apply({ type: "toggleFavorite", propertyId: id }),
    getSelectedProperty: () =>
      properties.find(
        (property) => property.id === routeState.current().selectedPropertyId,
      ) || properties[0],
    addLead,
    saveProperty,
    deleteProperty,
    goToRoute: (route, options = {}) => setRoute(route, options),
  };
  const routeTools = {
    getRoute,
    getSession,
    getSelectedBroker,
    getRouteInfo: () => routeState.current(),
    goToRoute: (route, options = {}) => setRoute(route, options),
  };

  add("topbar", TopbarComponent, routeTools);
  add("hero", HeroComponent, routeTools);
  add("stats", StatsComponent);
  add("featured", FeaturedComponent, propertyTools);
  add("map-navigation", MapNavigationComponent, propertyTools);
  add("announce", AnnounceComponent, { addLead });
  add("listing", ListingComponent, propertyTools);
  add("detail", DetailComponent, propertyTools);

  // Componente virtual de identificação do lead antes do envio.
  components.set("leadAuth", {
    async next(message = {}) {
      if (message.type === "closeModal") {
        leadAuthModal.open = false;
        leadAuthModal.error = "";
        render();
        return;
      }

      if (message.type !== "submitContactDetails") return;

      const name = message.fields.name;
      const phone = message.fields.phone;
      const email = message.fields.email;

      if (!FormValidator.antiSpamCheck("leadAuthForm")) {
        leadAuthModal.error =
          "Por favor, aguarde alguns segundos antes de enviar novamente.";
        render();
        return;
      }

      if (!name || !phone || !email) {
        leadAuthModal.error =
          "Por favor, preencha todos os campos obrigatórios (*).";
        render();
        return;
      }

      if (!FormValidator.validateName(name)) {
        leadAuthModal.error =
          "Nome inválido. Por favor, insira seu nome e sobrenome (somente letras).";
        render();
        return;
      }

      if (!FormValidator.validatePhone(phone)) {
        leadAuthModal.error =
          "Telefone inválido. Por favor, insira um número com DDD (mínimo 10 dígitos).";
        render();
        return;
      }

      if (!FormValidator.validateEmail(email)) {
        leadAuthModal.error =
          "E-mail inválido. Por favor, insira um endereço de e-mail correto.";
        render();
        return;
      }

      const cleanPhone = String(phone).replace(/[^\d]/g, "");
      const newClient = {
        id: `client-${Date.now()}`,
        name,
        phone: cleanPhone,
        email,
        profile: "Registrado pelo formulário de contato do imóvel.",
        focus: "Comprar",
        created: new Date().toISOString(),
      };

      dashboardContent.clients = [
        ...(dashboardContent.clients || []),
        newClient,
      ];

      sessionState.state = {
        ...sessionState.state,
        leadUser: {
          name,
          phone: cleanPhone,
          email,
        },
      };

      leadAuthModal.open = false;
      leadAuthModal.error = "";

      if (leadAuthModal.leadData) {
        const pending = {
          ...leadAuthModal.leadData,
          name,
          phone: cleanPhone,
          email,
        };
        leadAuthModal.leadData = null;

        // Cliente e lead são enviados juntos em uma única gravação do CMS.
        await submitLeadAndPersist(pending);
        return;
      }

      try {
        await persistCmsSnapshot(properties, dashboardContent);
        console.log("Novo cliente registrado no CMS com sucesso!");
      } catch (err) {
        console.error("Erro ao registrar cliente no CMS:", err);
      }

      render();
    },
  });
  add("editor", ProductEditorComponent, {
    getRoute,
    getSelectedProperty: () =>
      properties.find(
        (property) => property.id === routeState.current().selectedPropertyId,
      ) || null,
    saveProperty,
    deleteProperty,
    goToRoute: (route, options = {}) => setRoute(route, options),
    editorImage: () => properties[0]?.image || "",
  });
  add("brokers", BrokersComponent, {
    ...routeTools,
    saveBroker,
    deleteBroker,
    requestRender: () => requestRender(),
    goToRoute: (route, options = {}) => setRoute(route, options),
  });
  add("dashboard", DashboardComponentStateful, {
    requestRender: () => requestRender(),
    goToRoute: (route, options = {}) => setRoute(route, options),
    deleteProperty,
    saveBroker,
    deleteBroker,
    getSession: () => getSession(),
    getRouteInfo: () => routeState.current(),
    saveDashboard,
    renderAbout: () => renderComponent("dashboard-about"),
    renderEditions: () => renderComponent("dashboard-editions"),
  });
  add("login", LoginComponent, {
    login: async (email, password) => {
      try {
        await authenticateCmsSession(email, password);
        sessionState.apply({ type: "login" });
        const currentTab = routeState.current().dashboardTab;
        setRoute("dashboard", {
          dashboardTab:
            currentTab && currentTab !== "overview" ? currentTab : undefined,
        });
        return true;
      } catch {
        return false;
      }
    },
    requestRender: () => requestRender(),
  });
  add("contact", ContactComponent, { addLead });
  add("about", AboutComponent, { ...routeTools });
  add("dashboard-about", AboutComponent, {
    ...routeTools,
    requestRender: () => requestRender(),
    saveDashboard,
  });
  add("editions", DashboardEditionsComponent, {
    saveDashboard,
    requestRender: () => requestRender(),
  });
  add("dashboard-editions", DashboardEditionsComponent, {
    saveDashboard,
    requestRender: () => requestRender(),
  });
  add("financing", FinancingComponent, { addLead });
  add("footer", FooterComponent);
  add("floating-whats", FloatingWhatsComponent);

  const renderComponent = (id) => {
    const result = components.get(id)?.next();
    return result?.value || "";
  };
  const panel = (route, html) => {
    const offset = route !== "home";
    return /*html*/ `<div class="route-panel${offset ? " route-panel--offset" : ""}" ${routeAttrs(getRoute() === route)}>${html}</div>`;
  };
  const syncTopbarState = () => {
    const topbar = root.querySelector(".topbar");
    if (!topbar) return;
    const topbarHeight = topbar.getBoundingClientRect().height;
    const route = getRoute();
    const hero = route === "home" ? root.querySelector(".hero") : null;
    const heroScrollEnd = hero
      ? hero.offsetTop + hero.offsetHeight * 0.4 - topbarHeight
      : 64;
    const scrolledThreshold =
      route === "home" ? Math.max(64, heroScrollEnd) : 64;
    root.style.setProperty(
      "--toolbar-offset",
      `${Math.max(92, Math.round(topbarHeight + 28))}px`,
    );
    root.classList.toggle("is-scrolled", window.scrollY >= scrolledThreshold);
  };
  const renderLeadAuthModal = () => {
    if (!leadAuthModal.open) return "";
    
    return /*html*/`
      <div class="lead-modal-overlay">
        <style>
          .lead-modal-overlay {
            position: fixed;
            inset: 0;
            background: rgba(10, 17, 20, 0.7);
            backdrop-filter: blur(8px);
            z-index: 11000;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 16px;
            box-sizing: border-box;
          }
          .lead-modal-box {
            background: #ffffff;
            border-radius: 16px;
            box-shadow: 0 20px 50px rgba(0, 0, 0, 0.3);
            width: 100%;
            max-width: 440px;
            padding: 32px;
            box-sizing: border-box;
            position: relative;
            color: #16273f;
            font-family: var(--font-body, system-ui, sans-serif);
            animation: leadModalFadeIn 0.3s ease;
          }
          @keyframes leadModalFadeIn {
            from { opacity: 0; transform: translateY(-20px); }
            to { opacity: 1; transform: translateY(0); }
          }
          .lead-modal-close-btn {
            position: absolute;
            top: 16px;
            right: 16px;
            background: none;
            border: none;
            font-size: 1.5rem;
            color: #718096;
            cursor: pointer;
            transition: color 0.15s;
            line-height: 1;
          }
          .lead-modal-close-btn:hover {
            color: #16273f;
          }
          .lead-modal-box h3 {
            margin: 0 0 8px;
            font-size: 1.35rem;
            color: #16273f;
            font-weight: 700;
          }
          .lead-modal-box p {
            margin: 0 0 20px;
            font-size: 0.88rem;
            color: #718096;
            line-height: 1.5;
          }
          .lead-modal-form {
            display: flex;
            flex-direction: column;
            gap: 14px;
          }
          .lead-modal-error {
            color: #e53e3e;
            font-size: 0.82rem;
            margin-top: 4px;
            font-weight: 500;
          }
          .lead-modal-form .mini-field {
            display: flex;
            flex-direction: column;
            gap: 4px;
            text-align: left;
          }
          .lead-modal-form .mini-field label {
            font-size: 10px;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.05em;
            color: #4a5568;
            margin-bottom: 2px;
          }
          .lead-modal-form .mini-field input {
            padding: 10px 12px;
            border: 1px solid #cbd5e0;
            border-radius: 6px;
            font-size: 0.9rem;
            outline: none;
            box-sizing: border-box;
            width: 100%;
            background: #ffffff;
            color: #2d3748;
          }
          .lead-modal-form .mini-field input:focus {
            border-color: #bd8d44;
            box-shadow: 0 0 0 2px rgba(189, 141, 68, 0.15);
          }
          .lead-modal-form button[type="submit"] {
            margin-top: 10px;
            padding: 12px;
            border-radius: 6px;
            font-size: 0.9rem;
            font-weight: 600;
            cursor: pointer;
            width: 100%;
            border: none;
          }
        </style>
        <div class="lead-modal-box">
          <button class="lead-modal-close-btn" type="button" data-cid="leadAuth" data-message="closeModal" aria-label="Fechar">&times;</button>
          
          <h3>Dados de Contato</h3>
          <p>Preencha os dados abaixo de forma rápida para confirmar sua solicitação de contato.</p>
          
          <form class="lead-modal-form" data-cid="leadAuth" data-message="submitContactDetails">
            <div class="mini-field">
              <label>Nome Completo *</label>
              <input name="name" type="text" required placeholder="Digite seu nome completo">
            </div>
            <div class="mini-field">
              <label>Telefone / WhatsApp *</label>
              <input name="phone" type="text" required placeholder="(77) 981590101" autocomplete="tel">
            </div>
            <div class="mini-field">
              <label>E-mail *</label>
              <input name="email" type="email" required placeholder="seu@email.com" autocomplete="email">
            </div>
            
            ${leadAuthModal.error ? `<div class="lead-modal-error">${escapeHtml(leadAuthModal.error)}</div>` : ""}
            
            <button class="gold-btn" type="submit">Confirmar e Enviar Solicitação</button>
          </form>
        </div>
      </div>
    `;
  };

  const render = () => {
    const route = getRoute();
    root.classList.toggle("dashboard-mode", route === "dashboard");
    root.classList.toggle(
      "editor-mode",
      route === "imovel-novo" || route === "imovel-editar",
    );
    root.classList.toggle("route-home", route === "home");
    if (nativeDashboardOnly && route === "login") {
      root.innerHTML = renderComponent("login");
      syncTopbarState();
      return;
    }
    if (
      route === "dashboard" ||
      route === "imovel-novo" ||
      route === "imovel-editar"
    ) {
      root.innerHTML = /*html*/ `${route === "dashboard" ? renderComponent("dashboard") : renderComponent("editor")}`;
      syncTopbarState();
      return;
    }
    root.innerHTML = /*html*/ `
        ${renderComponent("topbar")}
        <main>
          ${panel("home", route === "home" ? `${renderComponent("hero")}${renderComponent("featured")}${renderComponent("map-navigation")}${renderComponent("brokers")}` : "")}
          ${panel("imoveis", route === "imoveis" ? renderComponent("listing") : "")}
          ${panel("imovel", route === "imovel" ? `${renderComponent("detail")}${renderComponent("brokers")}` : "")}
          ${panel("vendedores", route === "vendedores" || route === "brokers" ? renderComponent("brokers") : "")}
          ${panel("anuncie", route === "anuncie" ? renderComponent("announce") : "")}
          ${panel("login", route === "login" ? renderComponent("login") : "")}
          ${panel("contato", route === "contato" ? renderComponent("contact") : "")}
          ${panel("sobre", route === "sobre" ? renderComponent("about") : "")}
        </main>
        ${renderComponent("footer")}
        ${renderLeadAuthModal()}
    `;
    syncTopbarState();
  };
  requestRender = render;
  window.addEventListener("scroll", syncTopbarState, { passive: true });
  window.addEventListener("resize", syncTopbarState, { passive: true });
  const setRoute = (route, options = {}) => {
    let requestedRoute = ROUTES.includes(route) ? route : "home";
    if (requestedRoute === "financiamento") {
      requestedRoute = "imovel";
      setTimeout(() => {
        const sec = root.querySelector("#financing-section");
        if (sec) sec.scrollIntoView({ behavior: "smooth" });
      }, 150);
    }
    const nextRoute = nativeDashboardOnly && requestedRoute !== "login" ? "dashboard" : requestedRoute;
    const current = routeState.current();
    const propertyId =
      options.propertyId ||
      routeState.current().selectedPropertyId ||
      properties[0]?.id ||
      null;
    const hasBrokerId = Object.prototype.hasOwnProperty.call(
      options,
      "brokerId",
    );
    const brokerId = hasBrokerId
      ? options.brokerId || null
      : routeState.current().selectedBrokerId || null;
    const sameRoute =
      current.route === nextRoute &&
      current.selectedPropertyId === propertyId &&
      current.selectedBrokerId === brokerId &&
      current.dashboardTab === options.dashboardTab &&
      current.selectedEntityId === options.entityId &&
      current.operation === options.operation;
    if (sameRoute && options.syncHash !== false) return;
    if (sameRoute) return;
    routeState.setRoute(nextRoute, {
      propertyId,
      brokerId,
      dashboardTab: options.dashboardTab,
      entityId: options.entityId,
      operation: options.operation,
      authenticated: getSession().authenticated,
    });
    if (nextRoute !== "destaques") {
      featuredForceClose();
    }
    if (options.syncHash !== false) {
      const query = new URLSearchParams();
      if (options.operation) query.set("operation", options.operation);
      if (brokerId && (nextRoute === "vendedores" || nextRoute === "brokers"))
        query.set("brokerId", brokerId);
      if (nextRoute === "dashboard") {
        if (options.dashboardTab) query.set("tab", options.dashboardTab);
        if (options.entityId) query.set("entityId", options.entityId);
      }
      const nextHash =
        (nextRoute === "imovel" || nextRoute === "imovel-editar") && propertyId
          ? `#${nextRoute}#${encodeURIComponent(propertyId)}`
          : `#${nextRoute}${query.toString() ? `?${query.toString()}` : ""}`;
      window.history.pushState(
        {
          route: nextRoute,
          propertyId,
          brokerId,
          dashboardTab: options.dashboardTab || null,
          entityId: options.entityId || null,
          operation: options.operation || null,
        },
        "",
        nextHash,
      );
    }
    render();
    syncTopbarState();
    window.scrollTo({ top: 0, behavior: "smooth" });
  };
  const fieldsFrom = (form) => {
    const result = {};
    for (const [key, value] of new FormData(form).entries()) {
      const sanitized = typeof value === "string" ? FormValidator.sanitizeString(key, value) : value;
      if (key in result) {
        if (Array.isArray(result[key])) result[key].push(sanitized);
        else result[key] = [result[key], sanitized];
      } else {
        result[key] = sanitized;
      }
    }
    return result;
  };
  const dispatch = async (target, event) => {
    const component = components.get(target.dataset.cid);
    if (!component) return;
    const isForm = target.tagName === "FORM";
    const message = {
      type: target.dataset.message,
      name: target.dataset.name || target.name,
      direction: target.dataset.direction,
      propertyId: target.dataset.propertyId,
      value:
        target.dataset.value ??
        (target.isContentEditable ? target.textContent : target.value),
      checked: target.checked,
      fields: isForm ? fieldsFrom(target) : {},
      target,
      event,
    };
    const routeBefore = getRoute();
    try {
      const result = component.next(message);
      if (result?.then) await result;
    } catch (error) {
      console.error(`Action ${message.type} failed`, error);
    }
    if (message.type === "logout") {
      await closeCmsSession();
      sessionState.apply({ type: "logout" });
      setRoute("login");
      return;
    }
    if (getRoute() === routeBefore) {
      render();
      syncTopbarState();
    }
  };

  const featuredScrollState = {
    expandedPropertyId: null,
    expandedHeight: null,
    hoverTimerId: null,
    hoverPendingId: null,
    stageTimerId: null,
    expansionStage: null,
  };
  const featuredMeasureExpandedHeight = () => {
    const topbar = root.querySelector(".topbar");
    const topbarHeight = topbar?.getBoundingClientRect().height || 0;
    const viewportHeight = window.innerHeight || 900;
    return Math.max(
      420,
      Math.min(760, Math.round(viewportHeight - topbarHeight - 96)),
    );
  };
  const FEATURED_HOVER_ACTIVATION_DELAY = 520;
  const featuredClearTimers = () => {
    if (featuredScrollState.hoverTimerId)
      clearTimeout(featuredScrollState.hoverTimerId);
    if (featuredScrollState.stageTimerId)
      clearTimeout(featuredScrollState.stageTimerId);
    featuredScrollState.hoverTimerId = null;
    featuredScrollState.hoverPendingId = null;
    featuredScrollState.stageTimerId = null;
  };
  const featuredForceClose = ({ shouldRender = true } = {}) => {
    const hadState =
      featuredScrollState.expandedPropertyId ||
      featuredScrollState.hoverPendingId ||
      featuredScrollState.expansionStage;
    featuredClearTimers();
    featuredScrollState.expandedPropertyId = null;
    featuredScrollState.expandedHeight = null;
    featuredScrollState.expansionStage = null;
    if (!hadState || !shouldRender) return;
    render();
    syncTopbarState();
  };
  const featuredOpen = (propertyId) => {
    if (!propertyId || getRoute() !== "destaques") return;
    featuredClearTimers();
    featuredScrollState.expandedPropertyId = propertyId;
    featuredScrollState.expandedHeight = featuredMeasureExpandedHeight();
    featuredScrollState.expansionStage = "compact";
    render();
    syncTopbarState();
    featuredScrollState.stageTimerId = setTimeout(() => {
      if (featuredScrollState.expandedPropertyId !== propertyId) return;
      featuredScrollState.expansionStage = "expanded";
      featuredScrollState.stageTimerId = null;
      render();
      syncTopbarState();
      setTimeout(() => {
        if (featuredScrollState.expandedPropertyId !== propertyId) return;
        const expandedCard = root.querySelector(
          `.featured-showcase-card.is-expanded[data-property-id="${CSS.escape(propertyId)}"]`,
        );
        expandedCard?.scrollIntoView({
          behavior: "smooth",
          block: "center",
          inline: "nearest",
        });
      }, 160);
    }, 460);
  };
  const featuredScheduleOpen = (propertyId) => {
    if (!propertyId || getRoute() !== "destaques") return;
    if (
      featuredScrollState.expandedPropertyId ||
      featuredScrollState.hoverPendingId === propertyId
    )
      return;
    featuredClearTimers();
    featuredScrollState.hoverPendingId = propertyId;
    featuredScrollState.hoverTimerId = setTimeout(
      () => featuredOpen(propertyId),
      FEATURED_HOVER_ACTIVATION_DELAY,
    );
  };
  const featuredShouldCloseFromScrollIntent = (event) => {
    if (!featuredScrollState.expandedPropertyId)
      return Boolean(featuredScrollState.hoverPendingId);
    const expandedCard = root.querySelector(
      ".featured-showcase-card.is-expanded",
    );
    if (!expandedCard) return true;
    const rect = expandedCard.getBoundingClientRect();
    const point = event?.touches?.[0] || event;
    const y = typeof point?.clientY === "number" ? point.clientY : null;
    if (y === null) return false;
    const tolerance = Math.min(140, Math.max(72, rect.height * 0.16));
    return y <= rect.top + tolerance || y >= rect.bottom - tolerance;
  };
  const featuredCloseOnScrollIntent = (event) => {
    if (getRoute() !== "destaques") return;
    if (!featuredShouldCloseFromScrollIntent(event)) return;
    featuredForceClose();
  };
  window.addEventListener("wheel", featuredCloseOnScrollIntent, {
    passive: true,
  });
  window.addEventListener("touchmove", featuredCloseOnScrollIntent, {
    passive: true,
  });
  root.addEventListener("pointerover", (event) => {
    if (getRoute() !== "destaques") return;
    const card = event.target.closest(
      ".featured-showcase-card[data-property-id]",
    );
    if (!card) return;
    if (card.contains(event.relatedTarget)) return;
    featuredScheduleOpen(card.dataset.propertyId);
  });
  root.addEventListener("pointerout", (event) => {
    if (getRoute() !== "destaques") return;
    const grid = event.target.closest(".featured-showcase-grid");
    if (!grid || grid.contains(event.relatedTarget)) return;
    featuredForceClose();
  });
  let sidebarSwipeStart = null;
  root.addEventListener("touchstart", (event) => {
    if (getRoute() !== "dashboard") return;
    const touch = event.touches?.[0];
    if (!touch) return;
    const shell = root.querySelector(".dashboard-shell");
    const sidebar = shell?.querySelector(".dashboard-nav");
    if (!shell || !sidebar) return;
    const isCollapsed = shell.classList.contains("is-sidebar-collapsed");
    const drawerRect = sidebar.getBoundingClientRect();
    const drawerWidth = drawerRect.width;
    const canOpenFromOffset = isCollapsed && touch.clientX >= 28 && touch.clientX <= 96;
    const canCloseFromDrawer = !isCollapsed && touch.clientX >= drawerRect.left && touch.clientX <= drawerRect.right;
    if (!canOpenFromOffset && !canCloseFromDrawer) return;
    sidebarSwipeStart = {
      x: touch.clientX,
      y: touch.clientY,
      sidebar,
      shell,
      drawerWidth,
      initialProgress: isCollapsed ? 0 : 1,
      isCollapsed,
      progress: isCollapsed ? 0 : 1,
    };
  }, { passive: true });
  root.addEventListener("touchmove", (event) => {
    if (!sidebarSwipeStart) return;
    const touch = event.touches?.[0];
    if (!touch) return;
    const horizontalDistance = touch.clientX - sidebarSwipeStart.x;
    const verticalDistance = touch.clientY - sidebarSwipeStart.y;
    if (Math.abs(horizontalDistance) <= Math.abs(verticalDistance)) return;
    event.preventDefault();
    const progress = Math.max(0, Math.min(1, sidebarSwipeStart.initialProgress + horizontalDistance / sidebarSwipeStart.drawerWidth));
    sidebarSwipeStart.progress = progress;
    sidebarSwipeStart.shell.classList.add("is-sidebar-dragging");
    sidebarSwipeStart.sidebar.style.transform = `translateX(${(progress - 1) * sidebarSwipeStart.drawerWidth}px)`;
  }, { passive: false });
  root.addEventListener("touchend", (event) => {
    if (!sidebarSwipeStart) return;
    const gesture = sidebarSwipeStart;
    sidebarSwipeStart = null;
    const touch = event.changedTouches?.[0];
    if (!touch) return;
    const horizontalDistance = touch.clientX - gesture.x;
    const verticalDistance = touch.clientY - gesture.y;
    const finalProgress = Math.max(0, Math.min(1, gesture.initialProgress + horizontalDistance / gesture.drawerWidth));
    const shouldOpen = finalProgress >= 0.5;
    gesture.sidebar.style.transform = "";
    gesture.shell.classList.remove("is-sidebar-dragging");
    if (Math.abs(horizontalDistance) < 18 || Math.abs(horizontalDistance) <= Math.abs(verticalDistance)) return;
    if ((gesture.isCollapsed && shouldOpen) || (!gesture.isCollapsed && !shouldOpen)) {
      const toggle = gesture.sidebar.querySelector("[data-message='toggleSidebar']");
      if (toggle) void dispatch(toggle, event);
    }
  });

  /* property-code-blur-handler */
  root.addEventListener(
    "blur",
    (event) => {
      const input = event.target.matches?.('input[name="propertyCode"]')
        ? event.target
        : null;

      if (!input) return;

      const rawCode = String(input.value || "").trim();
      if (!rawCode) return;

      const normalizePropertyCode = (value) =>
        String(value || "")
          .normalize("NFD")
          .replace(/[\u0300-\u036f]/g, "")
          .toUpperCase()
          .replace(/[^A-Z0-9]/g, "");

      const searchedCode = normalizePropertyCode(rawCode);

      const property = properties.find((item) =>
        [
          item.codigo,
          item.code,
          item.propertyCode,
          item.reference,
          item.ref,
          item.id,
        ].some(
          (value) =>
            normalizePropertyCode(value) === searchedCode,
        ),
      );

      input.setCustomValidity("");

      if (!property) {
        input.setCustomValidity(
          `Nenhum imóvel encontrado para o código ${rawCode}.`,
        );
        input.reportValidity();
        return;
      }

      setRoute("imovel", {
        propertyId: property.id,
      });
    },
    true,
  );

  root.addEventListener("keydown", (event) => {
    const input = event.target.matches?.('input[name="propertyCode"]')
      ? event.target
      : null;

    if (!input || event.key !== "Enter") return;

    event.preventDefault();
    input.blur();
  });

  root.addEventListener("click", (event) => {
    const propertyCodeInput = event.target.closest(
      'input[name="propertyCode"]',
    );
    const routeTarget = propertyCodeInput
      ? null
      : event.target.closest("[data-route]");

    if (routeTarget) {
      event.preventDefault();
      const route = routeTarget.dataset.route;
      setRoute(route, {
        propertyId: routeTarget.dataset.propertyId || undefined,
        brokerId: routeTarget.dataset.brokerId || undefined,
        dashboardTab: routeTarget.dataset.dashboardTab || undefined,
        entityId: routeTarget.dataset.entityId || undefined,
        operation: routeTarget.dataset.operation || undefined,
      });
      if (route === "imovel" && (routeTarget.textContent.includes("Financiamento") || routeTarget.textContent.includes("Financiamentos"))) {
        setTimeout(() => {
          const sec = root.querySelector("#financing-section");
          if (sec) sec.scrollIntoView({ behavior: "smooth" });
        }, 150);
      }
      return;
    }
    const actionTarget = event.target.closest("[data-cid][data-message]");
    if (
      actionTarget &&
      actionTarget.tagName !== "FORM" &&
      !actionTarget.isContentEditable &&
      !(actionTarget.tagName === "INPUT" && actionTarget.type === "file")
    )
      void dispatch(actionTarget, event);
  });
  root.addEventListener("input", (event) => {
    const actionTarget = event.target.matches?.("[data-cid][data-message]")
      ? event.target
      : null;
    if (actionTarget) void dispatch(actionTarget, event);
  });
  root.addEventListener("change", (event) => {
    const actionTarget = event.target.matches?.("[data-cid][data-message]")
      ? event.target
      : null;
    if (actionTarget) void dispatch(actionTarget, event);
  });
  root.addEventListener("submit", (event) => {
    const actionTarget = event.target.closest("form[data-cid][data-message]");
    if (!actionTarget) return;
    event.preventDefault();
    void dispatch(actionTarget, event);
  });
  window.addEventListener("popstate", () => {
    const parsed = parseRoute();
    routeState.apply({
      type: "route",
      route: parsed.route,
      propertyId: parsed.propertyId,
      brokerId: parsed.brokerId || null,
      dashboardTab: parsed.dashboardTab || null,
      entityId: parsed.entityId || null,
      operation: parsed.operation || null,
      authenticated: getSession().authenticated,
    });
    render();
  });
  window.addEventListener("hashchange", () => {
    const parsed = parseRoute();
    if (
      parsed.route !== getRoute() ||
      parsed.propertyId !== routeState.current().selectedPropertyId ||
      parsed.brokerId !== routeState.current().selectedBrokerId ||
      parsed.dashboardTab !== routeState.current().dashboardTab ||
      parsed.entityId !== routeState.current().selectedEntityId ||
      parsed.operation !== routeState.current().operation
    ) {
      setRoute(parsed.route, {
        propertyId: parsed.propertyId,
        brokerId: parsed.brokerId || null,
        dashboardTab: parsed.dashboardTab || null,
        entityId: parsed.entityId || null,
        operation: parsed.operation || null,
        syncHash: false,
      });
    }
  });
  if (getRoute() === "dashboard" && !getSession().authenticated) {
    routeState.apply({
      type: "route",
      route: "login",
      propertyId: null,
      brokerId: null,
      dashboardTab: null,
      entityId: null,
      operation: null,
      authenticated: false,
    });
    window.history.replaceState({ route: "login" }, "", "#login");
    render();
  } else render();
  return {
    next: (message = {}) =>
      message.type === "render" ? render() : routeState.apply(message),
    states: { routeState, sessionState, dashboardState },
  };
};

window.SuaImobiliariaApp = { bootApp };

document.addEventListener("DOMContentLoaded", () => {
  loadCmsData()
    .catch((error) => {
      console.warn("CMS indisponivel, usando dados locais.", error);
    })
    .then(() => bootApp("#app"));
});
